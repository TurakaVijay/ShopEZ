import React from 'react'

const Bottom = () => {
  return (
    <div>
      <div className=' bg-zinc-600 flex justify-around h-10 items-center'>
      <div className="text-xl text-white font-serif ">
        @E-COMMERCE 
      </div>
      <div className=" text-white text-xl font-serif ">
      BIRLA INSTITUTE OF TECHNOLOGY & SCIENCE 
      </div>
    </div>
    </div>
  )
}

export default Bottom
